package com.higradius;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class display
 */
//@WebServlet("/Display")
public class Display extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Display() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
//        response.getWriter().append("Served at: ").append(request.getContextPath());
        int pageId=1;
        if(request.getParameter("page")!=null) {
            String spageId=request.getParameter("page");
            pageId=Integer.parseInt(spageId);
        }

        int total=8;
        if(pageId==1) {}
        else {
            pageId=pageId-1;
            pageId=pageId*total+1;
            }
        String url="jdbc:mysql://localhost:3306/mydatabase";
        String uname="root";
        String pass= "Google1234";
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection(url, uname, pass);
            if(con!=null) {
                System.out.println("Connection established");
            }
            String query="select name_customer, cust_number,doc_id,total_open_amount,due_in_date,predicted_date from mytable limit "+(pageId-1)+","+total;
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery(query);
        ArrayList<invoiceInfo> invoicedata= new ArrayList<>();
        while(rs.next()) {
            invoiceInfo iv=new invoiceInfo();
            String cust_name=rs.getString("name_customer");
            String cust_no=rs.getString("cust_number");
            String inv_no=rs.getString("doc_id");
            String amt=rs.getString("total_open_amount");
            String due_date=rs.getString("due_in_date");
            String note="Notes";
            String predict=rs.getString("predicted_date");
            System.out.println(cust_name + cust_no);
            iv.setCust_name(cust_name);
            iv.setCust_no(cust_no);
            iv.setInv_no(inv_no);
            iv.setAmt(amt);
            iv.setDue_date(due_date);
            iv.setNote(note);
            iv.setPredict(predict);
            invoicedata.add(iv);
        }
        Gson gson= new Gson();
        String data=gson.toJson(invoicedata);
        PrintWriter out =response.getWriter();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
                out.print(data);
                out.flush();
        }catch (Exception e) {
            System.out.println(e);
        }
    }
                
    

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}