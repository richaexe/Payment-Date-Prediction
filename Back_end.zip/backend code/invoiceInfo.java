package com.higradius;

//import java.io.IOException;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class invoiceInfo
 */
public class invoiceInfo {
    private String cust_name;
    private String cust_no;
    private String inv_no;
    private String amt;
    private String due_date;
    private String predict_date;
    private String note;


public void setData(String cust_name,String cust_no,String inv_no,String amo,String due_date,String predict_date,
String note) {
     this.cust_name=cust_name;
     this.cust_no=cust_no;
     this.amt= amo;
     this.due_date=due_date;
     this.inv_no=inv_no;
     this.predict_date=predict_date;
     this.note=note;


}

public String getCust_name() {
    return cust_name;
}
public void setCust_name(String cust_name) {
    this.cust_name = cust_name;
}
public String getCust_no() {
    return cust_no;
}
public void  setCust_no(String cust_no) {
    this.cust_no= cust_no;
}
public String getInv_no() { 
    return inv_no;
}

public void setInv_no(String inv_no) { 
    this.inv_no = inv_no;
}

public String getAmt() { 
    return amt;
}

public void setAmt(String amt) {
    this.amt=amt;
}
public String getDue_date() {
    return due_date;
}
public void setDue_date(String due_date) {
    this.due_date=due_date;
}
public String getNote() {
    return note;
}
public void setNote(String note) {
    this.note =note;
}
public String getPredict() {
    return predict_date;

}
public void setPredict(String Predict) {
    this.predict_date=Predict;

}
}